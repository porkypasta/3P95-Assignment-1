import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
public class arrayRandomizer {
    public static void main(String[] args) throws IOException {
        int breakOdds = 5;
        int holder = 0;
        FileWriter myWriter = new FileWriter("array.txt");
        Random num = new Random();
        while(true){
            // picks a random number
            holder = num.nextInt(1000);
            myWriter.write(Integer.toString(holder));
            // figures out whether to stop generating numbers
            if(num.nextInt(100)< breakOdds){
                break;
            }
            myWriter.write(" ");
        }
        myWriter.close();
    }
}

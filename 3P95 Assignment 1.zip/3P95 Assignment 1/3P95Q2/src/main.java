

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class main {
    static File myObj = new File("array.txt");
    static Scanner myReader;
    static File myOut = new File("sortedArray.txt");
    // try and catch for file error
    static {
        try {
            myReader = new Scanner(myObj);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("File not found");
        }
    }

    static String[] numStrArr;
    static String strArr;
    static int[] unsortedArray;




    public static void main(String[] args) throws IOException {
        strArr = myReader.nextLine();
        numStrArr = strArr.split(" ");
        FileWriter myWriter = new FileWriter("sortedArray.txt");
        unsortedArray = new int[numStrArr.length];
        //created array of ints
        for(int i = 0; i<numStrArr.length; i++){
            unsortedArray[i] = Integer.parseInt(numStrArr[i]);
        }
        boolean swapped = true;
        int holder;
        //bubble sort
        while(swapped == true){
            swapped = false;
            for(int j = 0; j < unsortedArray.length - 1; j++){
                //moves items further up the list and loops through list until complete
                if(unsortedArray[j]>unsortedArray[j+1]){
                    holder = unsortedArray[j];
                    unsortedArray[j] = unsortedArray[j+1];
                    unsortedArray[j+1] = holder;
                    swapped = true;
                }
            }
        }
            //writes sorted array file
            for(int c = 0; c< unsortedArray.length;c++){
                myWriter.write(unsortedArray[c] + " ");
            }
        myWriter.close();
    }
}

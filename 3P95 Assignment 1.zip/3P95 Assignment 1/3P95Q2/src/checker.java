import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class checker {
    static File myObj = new File("array.txt");
    static Scanner myReader;
    static File log = new File("logbook.txt");
    static Scanner logReader;
    static File sorted = new File("sortedArray.txt");
    static Scanner sortReader;
    static {
        try {
            myReader = new Scanner(myObj);
            logReader = new Scanner(log);
            sortReader = new Scanner(sorted);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Files not found");
        }
    }
    static String[] numStrArr;
    static String strArr;
    static int[] unsortedArray;
    public static void main(String[] args) throws IOException {
        strArr = sortReader.nextLine();
        numStrArr = strArr.split(" ");
        boolean broken = false;
        unsortedArray = new int[numStrArr.length];
        //makes array of ints
        for(int i = 0; i < numStrArr.length-1; i++){
            unsortedArray[i] = Integer.parseInt(numStrArr[i]);
        }
        //checks if the array sorted correctly
        for(int j = 0; j < unsortedArray.length-2; j++){

            if(unsortedArray[j] > unsortedArray[j+1]){
                broken = true;
            }
        }
        int lines;
        lines = Integer.parseInt(logReader.nextLine());
        lines++;
        FileWriter myWriter = new FileWriter("logbook.txt");
        myWriter.write(lines+"\n");
        // prints total
        lines = Integer.parseInt(logReader.nextLine());
        // prints amount of broken entries
        if(broken == true){
            lines++;
        }
        myWriter.write(lines+"\n");
        lines = Integer.parseInt(logReader.nextLine());
        // prints out total that succeded
        if(broken == false){
            lines++;
        }
        myWriter.write(lines+"\n");
        String squishy;
        // writes all previous logs
        while(logReader.hasNextLine()){
            squishy = logReader.nextLine();
            myWriter.write(squishy+"\n");
        }
        // adds newest log
        squishy = myReader.nextLine();
        myWriter.write(squishy + broken);
        myWriter.close();
    }
}
